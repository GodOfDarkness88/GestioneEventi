<script>
    import Carrousel from './../../lib/carrousel.svelte';
    import Navbar from './../../lib/navbar.svelte';
    import Footer from './../../lib/footer.svelte';
    let { data } = $props();
</script>

<div class="homepage-bg">
    <Navbar />

    <main class="homepage-main">
        <h1 class="homepage-title">Benvenuto su Event Manager</h1>
        <p class="homepage-subtitle">
            Scopri, partecipa e crea eventi nella tua città!
        </p>
        <section class="carousel-section">
            <Carrousel eventi={data.eventi} />
        </section>
    </main>
</div>

<Footer />

<style>
:global(body) {
    background: 
        linear-gradient(120deg, rgba(240,244,248,0.6) 0%, rgba(224,231,239,0.6) 100%),
        url('https://imgs.search.brave.com/muqUmDed13SJ9GeZRBWjpeAc-m0FwNKTsLe7o1j1ZCw/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jb250/ZW50LW1hbmFnZW1l/bnQtZmlsZXMuY2Fu/dmEuY29tL2Nkbi1j/Z2kvaW1hZ2UvZj1h/dXRvLHE9NzAvNjNm/NDRmZjMtOGJkZC00/NjU3LTg0NTgtNDk0/ZjUyOGE1ZjkzL0hv/d3RvcGxhbnlvdXJ3/ZWVrbHlzY2hlZHVs/ZS5qcGc');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    margin: 0;
    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
}

.homepage-bg {
    min-height: 100vh;
}

.homepage-main {
    max-width: 900px;
    margin: 0 auto;
    padding: 2.5rem 1rem 3rem 1rem;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.homepage-title {
    font-size: 2.3rem;
    color: #2563eb;
    margin-top: 2rem;
    margin-bottom: 0.5rem;
    text-align: center;
    letter-spacing: 1px;
    word-break: break-word;
}

.homepage-subtitle {
    font-size: 1.2rem;
    color: #334155;
    margin-bottom: 2.5rem;
    text-align: center;
    word-break: break-word;
}

.carousel-section {
    width: 100%;
    background: #4c7df9;
    border-radius: 16px;
    box-shadow: 0 4px 24px rgba(30, 41, 59, 0.08);
    padding: 2rem 1rem;
    margin-bottom: 2rem;
    display: flex;
    justify-content: center;
    min-width: 0;
    overflow-x: auto;
}

@media (max-width: 900px) {
    .homepage-main {
        max-width: 100vw;
        padding: 1.5rem 0.5rem 2rem 0.5rem;
    }
    .carousel-section {
        padding: 1.2rem 0.2rem;
    }
}

@media (max-width: 700px) {
    .homepage-main {
        padding: 1rem 0.2rem;
    }
    .carousel-section {
        padding: 1rem 0.1rem;
        border-radius: 10px;
    }
    .homepage-title {
        font-size: 1.5rem;
    }
    .homepage-subtitle {
        font-size: 1rem;
    }
}

@media (max-width: 480px) {
    .homepage-main {
        padding: 0.5rem 0.1rem;
    }
    .carousel-section {
        padding: 0.5rem 0.05rem;
        border-radius: 6px;
    }
    .homepage-title {
        font-size: 1.1rem;
    }
    .homepage-subtitle {
        font-size: 0.95rem;
    }
}
</style>