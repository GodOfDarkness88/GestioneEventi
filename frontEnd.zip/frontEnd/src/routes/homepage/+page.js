export const load = async ({ fetch }) => {
    try {
        console.log("Inizio caricamento dati...");
        const response = await fetch("/eventi.json");
        console.log("Response status:", response.status);

        if (!response.ok) {
            throw new Error(`Errore: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        console.log("Dati JSON:", data);
        return {eventi: data.eventi};
    } catch (error) {
        console.error("Errore durante il caricamento dei dati:", error);
        throw new Error("Impossibile caricare i dati degli eventi.");
    }
};