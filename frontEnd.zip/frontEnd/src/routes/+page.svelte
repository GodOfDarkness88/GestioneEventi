<script>
  import Navbar from "$lib/navbar.svelte";
  import Login from "$lib/login.svelte";
  import Descrizione from "$lib/descrizione.svelte";
</script>
<div>
  <Navbar />
</div>

<div class="main-content">
  <Login />
  <Descrizione />
</div>

<style>
  :global(body) {
    padding-top: 70px;
    background-image: url('https://wallpapercave.com/wp/wp7488231.jpg');
  }
  .main-content {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    gap: 2rem;
    margin-top: 2rem;
    min-height: 70vh;
    padding-left: 2rem;
    padding-right: 2rem;
  }
</style>
