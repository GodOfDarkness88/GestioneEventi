<div class="login-container">
  <h1>Accedi</h1>
  <form action="/homepage/">
    <label for="username">Nome utente</label>
    <input type="text" id="username" placeholder="Inserisci il tuo nome utente" />

    <label for="password">Password</label>
    <input type="password" id="password" placeholder="Inserisci la password" />

    <button type="submit">Accedi</button>
  </form>
</div>

<style>
  .login-container { 
    padding-top: 150px; /* spazio per navbar */
    max-width: 400px;
    margin: 0 auto;
    background-color: #f9fafb;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    font-family: 'Segoe UI', sans-serif;
  }

  h1 {
    text-align: center;
    margin-bottom: 1.5rem;
    color: #1e293b;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  label {
    font-weight: 500;
    color: #334155;
  }

  input {
    padding: 0.75rem;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    font-size: 1rem;
  }

  input:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
  }

  button {
    background-color: #08ff46;
    color: white;
    border: none;
    padding: 0.75rem;
    font-size: 1rem;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.2s ease;
  }

</style>