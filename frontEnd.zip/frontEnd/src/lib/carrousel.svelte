<script>
    import Card from './card.svelte';

    let { eventi } = $props();
    let current = $state(0);

    function prev() {
        current = (current - 1 + eventi.length) % eventi.length;
    }
    function next() {
        current = (current + 1) % eventi.length;
    }
</script>

{#if eventi && eventi.length > 0}
    <div class="carousel-container">
        <button class="nav-btn" onclick={prev} aria-label="Precedente">
            <span class="arrow">&#8592;</span>
        </button>
        <div class="carousel-card fade-in">
            <Card {...eventi[current]} />
        </div>
        <button class="nav-btn" onclick={next} aria-label="Successivo">
            <span class="arrow">&#8594;</span>
        </button>
    </div>
    <div class="carousel-indicators">
        {#each eventi as _, i}
            <span class:active={i === current}></span>
        {/each}
    </div>
{:else}
    <p class="no-events">Nessun evento disponibile.</p>
{/if}

<style>
.carousel-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 2.5rem;
    margin: 2rem 0 1rem 0;
}

.carousel-card {
    min-width: 350px;
    max-width: 420px;
    transition: box-shadow 0.2s;
    box-shadow: 0 4px 24px rgba(30, 41, 59, 0.10);
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.65); /* bianco semitrasparente */
    padding: 1.2rem 0.5rem;
    backdrop-filter: blur(10px); /* effetto sfocato */
    -webkit-backdrop-filter: blur(10px); /* supporto Safari */
}

.fade-in {
    animation: fadeIn 0.4s;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px);}
    to { opacity: 1; transform: translateY(0);}
}

.nav-btn {
    background: linear-gradient(135deg, #01f816 60%, #4ade80 100%); /* verde */
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 3rem;
    height: 3rem;
    font-size: 2rem;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(30,41,59,0.10);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s, transform 0.1s;
}
.nav-btn:hover {
    background: linear-gradient(135deg, #16a34a 60%, #22d3ee 100%); /* verde più scuro */
    transform: scale(1.08);
}
.arrow {
    display: block;
    font-size: 1.7rem;
    font-weight: bold;
}

.carousel-indicators {
    display: flex;
    justify-content: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
}
.carousel-indicators span {
    display: inline-block;
    width: 12px;
    height: 12px;
    background: #cbd5e1;
    border-radius: 50%;
    transition: background 0.2s, transform 0.2s;
}
.carousel-indicators span.active {
    background: #01f816;
    transform: scale(1.2);
}

.no-events {
    text-align: center;
    color: #64748b;
    font-size: 1.1rem;
    margin: 2rem 0;
}

@media (max-width: 600px) {
    .carousel-container {
        gap: 0.5rem;
    }
    .carousel-card {
        min-width: 90vw;
        max-width: 98vw;
        padding: 0.5rem 0.1rem;
    }
    .nav-btn {
        width: 2.2rem;
        height: 2.2rem;
        font-size: 1.2rem;
    }
}
</style>

