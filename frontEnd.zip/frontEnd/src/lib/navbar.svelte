<nav class="navbar">
  <div class="brand">
    <span class="logo"><a href="/homepage">📅</a></span>
    Event Manager
  </div>
  <div class="nav-links">
    <a href="/aggiunta/">Aggiungi Evento</a>
    <a href="/homepage/">Mostra Eventi</a>
    <a href="/modifica/">Modifica Evento</a>
  </div>
</nav>

<br>

<style>
  
  .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #1e293b;
    padding: 0.5rem 1.5rem; /* più compatto */
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
    font-family: 'Segoe UI', sans-serif;
    height: auto;
  }

  .brand {
    color: #ffffff;
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.4rem;
  }

  .logo {
    font-size: 1.2rem;
    line-height: 1;
  }

  .logo a {
    text-decoration: none;
    color: inherit;
  }

  .nav-links {
    display: flex;
    gap: 1rem;
  }

  .nav-links a {
    color: #d1d5db;
    text-decoration: none;
    font-size: 0.95rem;
    padding: 0.35rem 0.6rem;
    border-radius: 4px;
    transition: background-color 0.2s ease, color 0.2s ease;
  }

  .nav-links a:hover {
    background-color: #334155;
    color: #ffffff;
  }

  @media (max-width: 600px) {
    .navbar {
      flex-direction: column;
      align-items: flex-start;
    }

    .nav-links {
      flex-direction: column;
      gap: 0.4rem;
      margin-top: 0.5rem;
    }
  }
</style>
