<footer class="footer">
    <p>&copy; {new Date().getFullYear()} Event Manager &middot; Tutti i diritti riservati</p>
</footer>

<style>
.footer {
    width: 100%;
    background: #1e293b;
    color: #d1d5db;
    text-align: center;
    padding: 1rem 0;
    font-size: 1rem;
    position: relative;
    bottom: 0;
    left: 0;
}
</style>