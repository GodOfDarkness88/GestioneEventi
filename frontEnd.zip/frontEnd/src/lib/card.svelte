<script>
    let {data, luogo, oraFine, organizzatore, prezzo, titolo, copertina, tipologia } = $props();

    // Assicura che tipologia sia sempre un array
    if (typeof tipologia === 'string') tipologia = [tipologia];
</script>
<div>
    <div class="card">
        <div class="card-header">
            <h3>{titolo}</h3>
            <div class="copertina">
                <img src={copertina} alt="Copertina dell'evento" class="img-fluid" />
            </div>
            
            <h4>Tipologia:</h4>
            {#if tipologia.length === 0}
                <p>Nessuna tipologia disponibile</p>
            {/if}
            {#each tipologia as tipo}
                <div class="badge {tipo}">
                    {tipo}
                </div>
            {/each}
        </div>
        <div class="card-body">
            <h3>Luogo: {luogo}</h3>
            <h3>Data: {data}</h3>
            <p>by {organizzatore}</p>
        </div>
        <div class="card-footer">
            <button class="details-btn">
                <a href="/homepage/[1]">Vedi dettagli</a>
            </button>
        </div>
    </div>
</div>

<style>
.card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(30,41,59,0.07);
    padding: 2rem 1.5rem;
    margin: 0.5rem 0;
    max-width: 420px;
    min-width: 320px;
}

.card-header h3 {
    margin-bottom: 0.5rem;
    font-size: 1.3rem;
    color: #2563eb;
}

.card-header img {
    width: 100%;
    max-height: 180px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 0.7rem;
}

.badge {
    display: inline-block;
    padding: 0.2em 0.7em;
    border-radius: 8px;
    font-size: 0.95em;
    font-weight: 500;
    margin-bottom: 0.5em;
    margin-right: 0.5em;
    color: #fff;
    background: #2563eb;
    text-transform: capitalize;
}

.card-body {
    margin-top: 1rem;
    margin-bottom: 1rem;
    color: #334155;
    font-size: 1rem;
}

.card-footer {
    display: flex;
    justify-content: center;
    align-items: center;
}

.details-btn {
    background: #22c55e;
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 0.7em 1.5em;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

.details-btn:hover {
    background: #16a34a;
}

.details-btn a {
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}

.copertina {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 1rem;
    border-radius: 8px;
}

</style>