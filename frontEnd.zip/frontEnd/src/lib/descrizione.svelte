<div class="descrizione-box">
    <h1>Benvenuto su Event Manager!</h1>
    <p>
        La tua città ha molto da offrire... e noi ti aiutiamo a non perderti nulla!
        Con Event Manager puoi scoprire tutti gli eventi in corso vicino a te, dai concerti alle mostre, dalle fiere di quartiere agli spettacoli in centro.
        Hai un evento da condividere? Nessun problema! Dopo aver effettuato l'accesso, potrai aggiungerlo facilmente per farlo conoscere a tutta la comunità.
        Scopri, partecipa, crea: Event Manager è lo spazio dove la tua città prende vita!
    </p>
</div>

<style>
.descrizione-box {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    padding: 2rem 2.5rem;
    max-width: 420px;
    min-width: 320px;
    font-family: 'Segoe UI', sans-serif;
    color: #1e293b;
    
}
.descrizione-box h1 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: #2563eb;
    text-align: center;
}
.descrizione-box p {
    font-size: 1rem;
    line-height: 1.6;
    text-align: justify;
}
</style>

